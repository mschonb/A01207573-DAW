SELECT * 
FROM Materiales
WHERE clave = 1000 AND Costo = 1000

INSERT INTO Materiales values(1000, 'xxx', 1000) 

 Delete from Materiales where Clave = 1000 and Costo = 1000 

 -- Add primary key to materiales

 ALTER TABLE Materiales add constraint llaveMateriales PRIMARY KEY (Clave) 

  INSERT INTO Materiales values(1000, 'xxx', 1000) 

  sp_helpconstraint materiales 


  ALTER TABLE Proveedores add constraint llaveProveedores PRIMARY KEY (RFC) 

  ALTER TABLE Proyectos add constraint llaveProyectos PRIMARY KEY (Numero)

  --Add composite primary key
  
  ALTER TABLE Entregan add constraint llaveEntregan PRIMARY KEY (Clave,RFC,Numero,Fecha) 