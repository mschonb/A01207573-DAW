BULK INSERT a1207573.a1207573.[Materiales]
   FROM 'e:\wwwroot\a1207573\materiales.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

BULK INSERT a1207573.a1207573.[Proveedores]
   FROM 'e:\wwwroot\a1207573\proveedores.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

BULK INSERT a1207573.a1207573.[Proyectos]
   FROM 'e:\wwwroot\a1207573\proyectos.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

SET DATEFORMAT dmy
BULK INSERT a1207573.a1207573.[Entregan]
   FROM 'e:\wwwroot\a1207573\entregan.csv'
   WITH 
      (
         CODEPAGE = 'ACP',
         FIELDTERMINATOR = ',',
         ROWTERMINATOR = '\n'
      )

	  select * from proveedores

